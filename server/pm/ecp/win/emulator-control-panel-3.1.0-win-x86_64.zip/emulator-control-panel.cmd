@ECHO OFF



set sdk_path=%~dp0

set current_path=%sdk_path%\ecp.exe



set ECP_ARGS=""

set /a i=1


setlocal enableDelayedExpansion

for %%V in (%*) do (

	FOR /f "tokens=1,2 delims= " %%C IN (%%V) DO call :SetVar %%~C %%~D

)

goto EndCall



:SetVar

set key=%1

set val=%2

if "%key:~0,1%"=="-" (

	if %i% GEQ 10 (

		@echo "Not enough reserved environment variable."

		exit

	)

	set %VAR%%i%=%key%=%val%

	set /a i+=1

) else (

	if !ECP_ARGS!=="" (

		set ECP_ARGS="--%key%=%val%"

	) else (

		set ECP_ARGS=!ECP_ARGS! "--%key%=%val%"

	)

)

goto :eof



:EndCall



setlocal disableDelayedExpansion

if exist "%current_path%" (

	"%current_path%" %ECP_ARGS%

) else (

	@echo "%current_path%" does not exist.

)